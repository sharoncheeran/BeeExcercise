﻿namespace BeeExcercise
{
    public abstract class Bee //Parent class for bee
    {
        public bool Dead = false;
        public abstract void Damage(int dam);
    }
}