﻿using System;

namespace BeeExcercise
{
    class Program
    {
        static void Main(string[] args)
        {
            /*var numOfBees = 10;

            List<Worker> worker = new List<Worker>(); //Part 2: Instantiating a list of 10 for each bee type
            List<Queen> queen = new List<Queen>();
            List<Drone> drone = new List<Drone>();

            for (int i = 0; i < numOfBees; i++) //Creating 10 of each bee type
            {
                worker.Add(new Worker());
                queen.Add(new Queen());
                drone.Add(new Drone());
            }*/

            var worker = new Queen(); //Part 1: Testing to see if works 
            Console.WriteLine("Enter damage for bee: ");
            var user = int.Parse(Console.ReadLine());
            worker.Damage(user);
            Console.WriteLine("Status " + worker.Dead);
        }
    }
}
