﻿using System;

namespace BeeExcercise
{
    public class Worker : Bee
    {
        private float _healthProperty = 100f;

        public override void Damage(int dam)
        {
            if (dam >= 0 && dam <= 100)
            {
                if (Dead == false)
                {
                    _healthProperty = _healthProperty - dam; // same as (dam / healthProperty) * 100

                    if (_healthProperty < 70)
                    {
                        Dead = true;
                        Console.WriteLine("Worker health after damage: " + _healthProperty);
                        Console.WriteLine("Worker has died");
                    }
                    else
                    {
                        Console.WriteLine("Not dead");
                    }
                }
                else
                {
                    Console.WriteLine("The Worker has already died and health cannot be changed");
                }
            }
            else
            {
                Console.WriteLine("Damage should be between 0 and 100");
            }
        }
    }
}